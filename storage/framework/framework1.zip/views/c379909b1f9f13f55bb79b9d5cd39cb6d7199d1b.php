<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img class="d-block w-100" height="600px" src="https://scontent.fpoo2-1.fna.fbcdn.net/v/t1.0-9/117294038_2208887912579175_6423918857044055351_n.jpg?_nc_cat=107&_nc_sid=e3f864&_nc_ohc=N720LdhHBXAAX-MYDVf&_nc_ht=scontent.fpoo2-1.fna&oh=1502761cab4fa97c883e28a9e1e1dcc8&oe=5F73FD1C" alt="First slide">
      </div>
      <div class="carousel-item">
        <img class="d-block w-100" height="600px" src="https://scontent.fpoo2-1.fna.fbcdn.net/v/t1.0-9/117294038_2208887912579175_6423918857044055351_n.jpg?_nc_cat=107&_nc_sid=e3f864&_nc_ohc=N720LdhHBXAAX-MYDVf&_nc_ht=scontent.fpoo2-1.fna&oh=1502761cab4fa97c883e28a9e1e1dcc8&oe=5F73FD1C" alt="Second slide">
      </div>
      <div class="carousel-item">
        <img class="d-block w-100" height="600px" src="https://scontent.fpoo2-1.fna.fbcdn.net/v/t1.0-9/117294038_2208887912579175_6423918857044055351_n.jpg?_nc_cat=107&_nc_sid=e3f864&_nc_ohc=N720LdhHBXAAX-MYDVf&_nc_ht=scontent.fpoo2-1.fna&oh=1502761cab4fa97c883e28a9e1e1dcc8&oe=5F73FD1C" alt="Third slide">
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div><?php /**PATH /home/user/projetos/espacojf/resources/views/components/carousel.blade.php ENDPATH**/ ?>