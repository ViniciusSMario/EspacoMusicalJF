<?php $__env->startSection('title', 'Professores'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Professores</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Área para gerenciar os Professores.</p>
    <div class="row">
        <div class="col-sm-4">
          <div class="card">
            <div class="card-body" >
              <h5 class="card-title" >Adicionar Professores</h5>
              <p class="card-text">Adicione novos professores.</p>
              <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Adicionar</button>
            </div>
          </div>
        </div>

        <div class="col-sm-4">
          <div class="card">
            <div class="card-body" >
              <h5 class="card-title" >Relacionamento Professor-Curso</h5>
              <p class="card-text">Adicione novos relacionamentos.</p>
              <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalRelationship" data-whatever="@mdo">Adicionar</button>
            </div>
          </div>
        </div>
    </div>
      
    <hr>
    <div class="row">
      <h1>Professores Cadastrados</h1>
        <table class="table table-hover">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Professor</th>
                <th scope="col">Formação</th>
                <th scope="col">Ações</th>
              </tr>
            </thead>
            <tbody>
              
                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th scope="row"><?php echo e($t->id); ?></th>
                  <td><?php echo e($t->name); ?></td>
                  <td><?php echo e($t->information); ?></td>
                  <td>
                    <a class="btn btn-success"  style="color: #FFF;margin-right:20px "role="button" data-toggle="modal" data-target="#myModal2<?php echo e($t->id); ?>" data-id="<?php echo e($t->id); ?>">Editar</button>
                    <a class="btn btn-danger" style="color: #FFF" role="button" data-toggle="modal" data-target="#myModal3<?php echo e($t->id); ?>" data-id="<?php echo e($t->id); ?>">Excluir</button>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </tbody>
          </table>
    </div>

    <div class="row">
      <h1>Professores-Cursos</h1>
        <table class="table table-hover">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Professor</th>
                <th scope="col">Curso</th>
                <th scope="col">Ações</th>
              </tr>
            </thead>
            <tbody>
              
                <?php $__currentLoopData = $teacherCourse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th scope="row"><?php echo e($tc->id_tc); ?></th>
                  <td><?php echo e($tc->teacher); ?></td>
                  <td><?php echo e($tc->course); ?></td>
                  <td>
                    <a class="btn btn-danger" style="color: #FFF" role="button" data-toggle="modal" data-target="#excRelation<?php echo e($tc->id_tc); ?>" data-id="<?php echo e($tc->id_tc); ?>">Excluir</button>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </tbody>
          </table>
    </div>

   
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Adicionar Professor</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form name="form" action="/admin/teachers" method="POST" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Nome:</label>
            <input type="text" class="form-control" id="name" name="name">
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Formação:</label>
            <textarea class="form-control" id="information" name="information"></textarea>
          </div>
          <div class="form-group">
            <label for="image" class="col-form-label">Foto de Perfil:</label>
            <input type="file" class="form-control" id="image" name="image" accept="image/*"/>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
        <input type="submit" class="btn btn-primary" value="Adicionar">
      </div>
    </form>

    </div>
  </div>
</div>


<div class="modal fade" id="modalRelationship" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Adicionar Relacionamento</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form name="form" action="/admin/teachers/courses" method="POST" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Curso:</label>
            <select class="form-control" name="course_id">
              <option value="">Selecione...</option>
              <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Professor:</label>
            <select class="form-control" name="teacher_id">
              <option value="">Selecione...</option>
              <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($t->id); ?>"><?php echo e($t->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
        <input type="submit" class="btn btn-primary" value="Adicionar">
      </div>
    </form>

    </div>
  </div>
</div>



<?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="myModal2<?php echo e($t->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Editar Professor</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form name="form" action="/admin/teachers/update/<?php echo e($t->id); ?>" method="POST" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Nome:</label>
            <input type="text" class="form-control" id="name" name="name" <?php echo e($t->name); ?> ? value="<?php echo e($t->name); ?>" : value="" >
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Descrição:</label>
            <textarea class="form-control" id="information" name="information"> <?php echo e($t->information); ?> </textarea>
          </div>
          <div class="form-group">
            <label for="image" class="col-form-label">Imagem:</label>
            <input type="file" class="form-control" id="image" name="image" accept="image/*" <?php echo e($t->image); ?> ? value="<?php echo e($t->image); ?>" : value=""  />
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
        <input type="submit" class="btn btn-primary" value="Alterar">
      </div>
    </form>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="myModal3<?php echo e($t->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Excluir Professor</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form name="form" action="/admin/teachers/delete/<?php echo e($t->id); ?>" method="GET" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <p>Tem certeza que deseja excluir esse professor?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
        <input type="submit" class="btn btn-danger" value="Excluir">
      </div>
    </form>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__currentLoopData = $teacherCourse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="excRelation<?php echo e($tc->id_tc); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Excluir Relacionamento</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form name="form" action="/admin/teachers/courses/delete/<?php echo e($tc->id_tc); ?>" method="GET" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <p>Tem certeza que deseja excluir esse relacionamento?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
        <input type="submit" class="btn btn-danger" value="Excluir">
      </div>
    </form>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/projetos/espacojf/resources/views/teachers.blade.php ENDPATH**/ ?>